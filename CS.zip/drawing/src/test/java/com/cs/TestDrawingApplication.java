package com.cs;

import com.cs.operation.BucketFill;
import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import static org.junit.Assert.assertNotNull;

/**
 * Created by Jacky on 2018/7/16.
 */
public class TestDrawingApplication {

    @Test
    public void whenGetBeans_returnsBean() {
        ApplicationContext applicationContext = new ClassPathXmlApplicationContext("com.cs.drawing.xml");
        BucketFill bucketFill = applicationContext.getBean("BucketFill", BucketFill.class);
        assertNotNull(bucketFill);
    }
}
