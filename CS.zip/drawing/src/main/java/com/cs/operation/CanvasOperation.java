package com.cs.operation;

import com.cs.element.Canvas;

/**
 * Created by Jacky on 2018/7/15.
 */
public interface CanvasOperation {
    void paint();
    char getOperationType();
    void setCommand(String command);
    void printUsage();
}
