package com.cs.operation;

import com.cs.element.Canvas;

/**
 * Created by Jacky on 2018/7/15.
 */
public class PaintCanvas implements CanvasOperation{

    private int w;
    private int h;
    private Canvas canvas;
    private char operationType='C';

    public PaintCanvas() {}


    @Override
    public void paint() {
        Canvas.init(w,h);
        canvas = Canvas.getInstance();
        canvas.paint();
    }

    @Override
    public char getOperationType() {
        return operationType;
    }

    @Override
    public void setCommand(String command) {
        String[] args = command.substring(1).trim().split(" ");
        if(args.length ==2) {
            this.w = Integer.parseInt(args[0]);
            this.h = Integer.parseInt(args[1]);
        }else{
            printUsage();
        }
    }

    @Override
    public void printUsage() {
        System.out.println("C w h           Should create a new canvas of width w and height h.");
    }
}
