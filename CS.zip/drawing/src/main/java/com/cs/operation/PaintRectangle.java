package com.cs.operation;

import com.cs.element.Canvas;

/**
 * Created by Jacky on 2018/7/15.
 */
public class PaintRectangle implements CanvasOperation {
    @Override
    public void paint() {

    }

    @Override
    public char getOperationType() {
        return 0;
    }

    @Override
    public void setCommand(String command) {

    }

    @Override
    public void printUsage() {

    }
}
