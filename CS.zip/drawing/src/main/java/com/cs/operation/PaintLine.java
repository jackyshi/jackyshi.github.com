package com.cs.operation;

import com.cs.element.Canvas;
import com.cs.element.Point;

/**
 * Created by Jacky on 2018/7/15.
 */
public class PaintLine implements CanvasOperation {

    private int x1;
    private int y1;
    private int x2;
    private int y2;
    private Canvas canvas;
    private char operationType='L';

    public PaintLine() { }

    @Override
    public void paint() {
        canvas = Canvas.getInstance();
        if(canvas==null)
            return;
        if(x1 <= x2 && y1 <= y2 && x2 <=canvas.width && y2<=canvas.height){
            for(int i=x1;i<=x2;i++){
                for(int j=y1;j<=y2;j++){
                    Point point = new Point(j,i);
                    canvas.contents.put(point,'x');
                }
            }
            canvas.paint();
        }else{
            System.out.println("Start or End point out of the scope of canvas");
        }
    }

    @Override
    public char getOperationType() {
        return operationType;
    }

    @Override
    public void setCommand(String command) {
        String[] args = command.substring(1).trim().split(" ");
        if(args.length ==4) {
            this.x1 = Integer.parseInt(args[0]);
            this.y1 = Integer.parseInt(args[1]);
            this.x2 = Integer.parseInt(args[2]);
            this.y2 = Integer.parseInt(args[3]);
        }else{
            printUsage();
        }
    }

    @Override
    public void printUsage() {
        System.out.println("L x1 y1 x2 y2   Should create a new line from (x1,y1) to (x2,y2). Currently only\n" +
                "                horizontal or vertical lines are supported. Horizontal and vertical lines\n" +
                "                will be drawn using the 'x' character.");
    }
}
