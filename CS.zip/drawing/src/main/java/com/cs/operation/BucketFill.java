package com.cs.operation;

import com.cs.element.Canvas;

/**
 * Created by Jacky on 2018/7/15.
 */
public class BucketFill implements CanvasOperation {

    int x=0;
    @Override
    public void paint() {

    }

    @Override
    public char getOperationType() {
        return 0;
    }

    @Override
    public void setCommand(String command) {

    }

    @Override
    public void printUsage() {

    }
}
