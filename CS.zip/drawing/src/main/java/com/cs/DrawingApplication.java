package com.cs;

import com.cs.invoker.*;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import java.util.Scanner;

/**
 * Created by Jacky on 2018/7/15.
 */
public class DrawingApplication {

    private static final Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {
        ApplicationContext applicationContext = new ClassPathXmlApplicationContext("com.cs.drawing.xml");
        CanvasOperationExecutor canvasOperationExecutor = (CanvasOperationExecutor) applicationContext.getBean("CanvasOperationExecutor");
        while (true) {
            String command = scanner.nextLine();
            canvasOperationExecutor.executeOperation(command);
        }
    }
}
