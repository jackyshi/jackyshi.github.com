package com.cs.invoker;

import com.cs.operation.CanvasOperation;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Jacky on 2018/7/15.
 */
public class CanvasOperationExecutor {
    public List<CanvasOperation> getCanvasOperationList() {
        return canvasOperationList;
    }

    public void setCanvasOperationList(List<CanvasOperation> canvasOperationList) {
        this.canvasOperationList = canvasOperationList;
    }

    private List<CanvasOperation> canvasOperationList = new ArrayList<>();

    public void executeOperation(String command) {
        canvasOperationList.forEach(canvasOperation -> {
                    if (command.charAt(0) == canvasOperation.getOperationType()) {
                        canvasOperation.setCommand(command);
                        canvasOperation.paint();
                    }
                }
            );
    }
}
