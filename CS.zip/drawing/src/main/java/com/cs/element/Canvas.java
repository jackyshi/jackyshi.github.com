package com.cs.element;

import java.util.HashMap;

/**
 * Created by Jacky on 2018/7/15.
 */
public class Canvas {

    private static Canvas canvas = null;

    public int width;
    public int height;
    public HashMap<Point,Character> contents = new HashMap();

    private Canvas(int width, int height) {
        this.width = width;
        this.height = height;
    }

    public static Canvas getInstance() {
        if(canvas == null) {
            System.out.println("Canvas is not created yet");
        }
        return canvas;
    }

    public synchronized static Canvas init(int width, int height) {
        if (canvas != null) {
            System.out.println("Existing canvas will be overwritten");
        }
        canvas = new Canvas(width,height);
        return canvas;
    }

    public void paint() {
        for(int i=0; i<=height+1; i++){
            for(int j=0; j<=width+1; j++){
                if(i==0 || i==height+1) {
                    System.out.print("-");
                    if(j==width+1){
                        System.out.println("");
                    }
                }else if(j==0 || j==width+1) {
                    System.out.print("|");
                    if(j==width+1){
                        System.out.println("");
                    }
                }else{
                    Point point = new Point(i,j);
                    if(contents.containsKey(point)) {
                        System.out.print(contents.get(point));
                    }else{
                        System.out.print(" ");
                    }
                }

            }
        }

    }
}
