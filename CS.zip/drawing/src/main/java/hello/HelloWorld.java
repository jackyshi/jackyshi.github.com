package hello;

/**
 * Created by Jacky on 2018/7/14.
 */
public class HelloWorld {
    public static void main(String[] args) {
        System.out.println("Hello World");
    }
}
