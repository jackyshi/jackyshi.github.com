import dash
import dash_table
import pandas as pd
import dash_core_components as dcc
import dash_html_components as html

df = pd.read_csv('solar.csv')

external_stylesheets = ['https://stackpath.bootstrapcdn.com/bootstrap/4.2.1/css/bootstrap.min.css']

app = dash.Dash(__name__)

app.layout =  html.Div([dash_table.DataTable(
    id='table',
    columns=[{"name": i, "id": i} for i in df.columns],
    data=df.to_dict('records'),
        style_cell_conditional=[
        {
            'if': {'column_id': c},
            'textAlign': 'left'
        } for c in ['Date', 'Region']
    ],
    style_data_conditional=[
        {
            'if': {'row_index': 'odd'},
            'backgroundColor': 'rgb(248, 248, 248)'
        }
    ],
    style_header={
        'backgroundColor': 'rgb(230, 230, 230)',
        'fontWeight': 'bold'
    })],
    className='table-responsive'
)

if __name__ == '__main__':
    app.run_server(debug=True)