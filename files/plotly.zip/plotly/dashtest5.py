# -*- coding: utf-8 -*-
"""
Created on Thu Jun 27 02:18:23 2019

@author: admin
"""
import dash
import dash_core_components as dcc
import dash_html_components as html
import json, urllib
import plotly.plotly as py
import pandas as pd
import numpy as np

app = dash.Dash()

refugee_df = pd.read_csv('refugee-movement.csv')

data_trace = dict(
    type='sankey',
    domain = dict(
      x =  [0,1],
      y =  [0,1]
    ),
    orientation = "h",
    valueformat = ".0f",
    node = dict(
      pad = 10,
      thickness = 30,
      line = dict(
        color = "black",
        width = 0.5
      ),
      label =  refugee_df['Node, Label'].dropna(axis=0, how='any'),
      color = refugee_df['Color']
    ),
    link = dict(
      source = refugee_df['Source'].dropna(axis=0, how='any'),
      target = refugee_df['Target'].dropna(axis=0, how='any'),
      value = refugee_df['Value'].dropna(axis=0, how='any'),
  )
)

layout =  dict(
    title = "Refugee movement through Manus and Nauru, via <a href='http://www.bryanbrussee.com/sankey.html'>Bryan Brussee</a>",
    height = 772,
    width = 950,
    font = dict(
      size = 10
    ),    
)


fig = dict(data=[data_trace], layout=layout)

app.layout = html.Div(children=[
    html.H1(children='Dash Tutorials'),
    dcc.Graph(
        id='example',
        figure=fig
    )])

if __name__ == '__main__':
    app.run_server(debug=True)