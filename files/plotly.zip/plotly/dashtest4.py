# -*- coding: utf-8 -*-
"""
Created on Thu Jun 27 02:05:51 2019

@author: admin
"""

import dash
import dash_core_components as dcc
import dash_html_components as html
import plotly.graph_objs as go
import plotly.io as pio

import plotly.figure_factory as ff
import numpy as np

app = dash.Dash()

x = np.random.randn(1000)  
hist_data = [x]
group_labels = ['distplot']

fig = ff.create_distplot(hist_data, group_labels)

app.layout = html.Div(children=[
    html.H1(children='Dash Tutorials'),
    dcc.Graph(
        id='example',
        figure=fig
    )])

if __name__ == '__main__':
    app.run_server(debug=True)