#!/bin/bash

cd ~/q/Workshop/7.API/java
javac BulkInserter.java
java BulkInserter
