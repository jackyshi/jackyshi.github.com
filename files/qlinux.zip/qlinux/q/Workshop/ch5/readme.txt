The run application will run the real time tickerplant demo.

Please note, Terminal|Edit|Profile Preferences|Title and Command|When command exits: must be set to "Hold the terminal open".
