#!/bin/bash

cd ~/q/Workshop/7.API/java
javac SingleInserter.java
java SingleInserter
