import flask
from flask import Flask, render_template, request
from flask_socketio import SocketIO, emit
from dash import Dash
import dash_html_components as html
import dash_core_components as dcc
from dash.dependencies import Input, Output, State
from Constant import indexStr
import dashapp
from dashapp import dash_app

app = Flask(__name__)
app.config['SECRET_KEY'] = 'secret!'
socketio = SocketIO(app, async_mode='threading', cors_allowed_origins="*")
cache = dict.fromkeys(['eventMsg','broadCastMsg'])

# page route
@app.route('/')
def home():
    return render_template('home.html')

from dashapp.dashapp1.layout import layout
from dashapp.dashapp1.callbacks import register_callbacks
dash_app.register_dashapps(app, 'dashboard', layout, register_callbacks, socketio, cache)

#@app.route('/dashboard')
#def render_dashboard():
#    return flask.redirect('/dashboard/')

@app.route('/about')
def about():
    return render_template('about.html')


@app.route('/edit', methods=['GET','POST'])
def edit():
    global socketio, cache

    if request.method == 'GET':
        layout_file = open("test/layout1.py", "r")
        layout_code = layout_file.read()
        print(layout_code)
        callback_file = open("test/callback1.py", "r")
        callback_code = callback_file.read()
        print(callback_code)
    if request.method == 'POST':
        reportId = request.form.get('reportId')
        layout_code = request.form.get('layout_code')
        print(layout_code)
        test_layout=dash_app.create_layout(layout_code)
        callback_code = request.form.get('callback_code')
        print(callback_code)
        #dash_app.register_dashapps(app, 'dashboard2', layout, register_callbacks, socketio, cache)
        dash_app.register_dashapps(app, reportId, test_layout, callback_code, socketio, cache)
    return render_template('edit.html', layout_code=layout_code, callback_code=callback_code)

# socketio event
@socketio.on('my event')
def test_message(message):
    cache['eventMsg']=str(message)
    print(message)
    #emit('my response', {'data': 'got it!'})

@socketio.on('my broadcast event')
def test_message2(message):
    cache['broadCastMsg']=str(message)
    emit('my response', {'data': message['data']}, broadcast=True)

@socketio.on('connect')
def test_connect():
    emit('my response', {'data': 'Connected'})

@socketio.on('disconnect')
def test_disconnect():
    print('Client disconnected')

if __name__ == '__main__':
    socketio.run(app, debug=False)