import flask
from flask import Flask, render_template
from flask_socketio import SocketIO, emit
from dash import Dash
import dash_html_components as html
import dash_core_components as dcc
from dash.dependencies import Input, Output, State
from Constant import indexStr

app = Flask(__name__)
app.config['SECRET_KEY'] = 'secret!'
socketio = SocketIO(app, async_mode='threading', cors_allowed_origins="*")

eventMsg=""
broadCastMsg=""

# dash
dash_app1 = Dash(__name__, server = app, url_base_pathname='/dashboard/')
dash_app1.layout = html.Div([
    html.H1('Dash App'),
    html.Div(id='live-update-text'),
    html.Div(id='live-update-text-2'),
    dcc.Input(id='dash-input', value=''),
    html.Button('Publish', id='dash-button', n_clicks=0),
    dcc.Interval(
        id='interval-component',
        interval=1*500,
        n_intervals=0
    )
])

dash_app1.enable_dev_tools(debug=False)
dash_app1.index_string=indexStr

@dash_app1.callback(Output('live-update-text', 'children'),
            [Input('interval-component', 'n_intervals')])
def update_data(n):
    return [
        html.Span(eventMsg),
        html.Span(broadCastMsg)
    ]

@dash_app1.callback(
    Output('live-update-text-2','children'),
    [Input('dash-button', 'n_clicks')],
    [State('dash-input', 'value')])
def update_publish_data(n_clicks,value):
    res=[]
    if n_clicks > 0:
        print('callback', socketio)
        socketio.emit('my response', {'data':value}, broadcast=True)
        res = [html.Span(value)]
    return res

# page route
@app.route('/')
def home():
    return render_template('home.html')

@app.route('/dashboard')
def render_dashboard():
    return flask.redirect('/dashboard/')

@app.route('/about')
def about():
    return render_template('about.html')

# socketio event
@socketio.on('my event')
def test_message(message):
    global eventMsg
    eventMsg=str(message)
    print(message)
    #emit('my response', {'data': 'got it!'})

@socketio.on('my broadcast event')
def test_message2(message):
    global broadCastMsg
    broadCastMsg=str(message)
    emit('my response', {'data': message['data']}, broadcast=True)

@socketio.on('connect')
def test_connect():
    emit('my response', {'data': 'Connected'})

@socketio.on('disconnect')
def test_disconnect():
    print('Client disconnected')

if __name__ == '__main__':
    socketio.run(app, debug=True)