from flask import Flask, render_template
from flask_nav import Nav
from flask_nav.elements import *

nav = Nav()

app = Flask(__name__)

@app.route('/')
def home():
    return render_template('home.html')

@app.route('/products/<product>/')
def products(product):
    return render_template('index2.html', msg='Buy our {}'.format(product))

@app.route('/about')
def about():
    return render_template('about.html')

nav.init_app(app)

app.run(debug=True,threaded=True)