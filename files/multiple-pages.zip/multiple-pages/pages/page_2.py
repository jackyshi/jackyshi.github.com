import dash
import dash_core_components as dcc
import dash_bootstrap_components as dbc
import dash_html_components as html
from dash.dependencies import Input, Output, State

from app import app

page_2_layout = html.Div([
    dbc.Button(
        "Open collapse",
        id="collapse-button",
        className="mb-3",
        color="primary",
    ),
    dbc.Collapse(
        dbc.Textarea(className="mb-3", placeholder="A Textarea"),
        id="content-collapse",
    ),
])

@app.callback(
    Output("content-collapse", "is_open"),
    [Input("collapse-button", "n_clicks")],
    [State("content-collapse", "is_open")],
)
def toggle_collapse(n, is_open):
    if n:
        return not is_open
    return is_open