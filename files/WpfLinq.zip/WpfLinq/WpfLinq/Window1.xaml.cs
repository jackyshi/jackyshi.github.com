﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;

namespace WpfApplication5
{
	public class Event
	{
		public int PID { get; set; }
		public string Desc { get; set; }
		public DateTime EventTime { get; set; }
	}

	/// <summary>
	/// Interaction logic for Window1.xaml
	/// </summary>
	public partial class Window1 : Window
	{
        public Window1()
        {
            InitializeComponent();

            Random rnd = new Random();
            /*
            var data = new List<Event>()
            {
                new Event() { PID = 1, Desc="Process A", EventTime = DateTime.Now.AddHours(rnd.Next(1, 10)) },
                new Event() { PID = 1, Desc="Process A", EventTime = DateTime.Now.AddHours(rnd.Next(10, 20)) },
                new Event() { PID = 2, Desc="Process B", EventTime = DateTime.Now.AddHours(rnd.Next(20, 30)) },
                new Event() { PID = 2, Desc="Process B", EventTime = DateTime.Now.AddHours(rnd.Next(30, 40)) },
                new Event() { PID = 3, Desc="Process C", EventTime = DateTime.Now.AddHours(rnd.Next(40, 50)) }
            };

            var result =
                from d in data
                group d by new { d.PID, d.Desc } into pg
                select new { Process = pg.Key, Items = pg };

            TopLevelListBox.DataContext = result;
            */
            AutoResetEvent pause = new AutoResetEvent(false);

            Task.Factory.StartNew(() =>
            {
                while(true)
                {
                    var data = new List<Event>()
                    {
                        new Event() { PID = 1, Desc="Process A", EventTime = DateTime.Now.AddHours(rnd.Next(1, 10)) },
                        new Event() { PID = 1, Desc="Process A", EventTime = DateTime.Now.AddHours(rnd.Next(10, 20)) },
                        new Event() { PID = 2, Desc="Process B", EventTime = DateTime.Now.AddHours(rnd.Next(20, 30)) },
                        new Event() { PID = 2, Desc="Process B", EventTime = DateTime.Now.AddHours(rnd.Next(30, 40)) },
                        new Event() { PID = 3, Desc="Process C", EventTime = DateTime.Now.AddHours(rnd.Next(40, 50)) }
                    };

                    var result =
                    from d in data
                    group d by new { d.PID, d.Desc } into pg
                    select new { Process = pg.Key, Items = pg };

                    this.Dispatcher.BeginInvoke((Action) (() => { TopLevelListBox.DataContext = result; }));

                    pause.WaitOne(100, true);

                }
            });
        }
	}
}
