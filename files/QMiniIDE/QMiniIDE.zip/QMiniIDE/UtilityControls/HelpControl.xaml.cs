﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace UtilityControls
{
    /// <summary>
    /// HelpControl.xaml 的交互逻辑
    /// </summary>
    public partial class HelpControl : UserControl
    {
        public HelpControl()
        {
            InitializeComponent();
            wbHelp.Navigate("http://code.kx.com/wiki/Reference");
        }

        private void txtUrl_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter)
                wbHelp.Navigate(txtUrl.Text);
        }

        private void wbhelp_Navigating(object sender, System.Windows.Navigation.NavigatingCancelEventArgs e)
        {
            SuppressScriptErrors(wbHelp, true);
            string origUrl = e.Uri.OriginalString;

            if (!origUrl.Contains("printable=yes"))
            {
                if (!origUrl.Contains("wikiSearch"))
                {
                    string contentUrl = origUrl.Substring(24);
                    string titleUrl = "title=" + contentUrl;
                    string newUrl = "http://code.kx.com/mediawiki/index.php?" + titleUrl + "&printable=yes";
                    wbHelp.Navigate(newUrl);
                }
                else
                {
                    string contentUrl = origUrl.Substring(origUrl.IndexOf("for=") + 4);
                    contentUrl = contentUrl.Substring(0, contentUrl.IndexOf("&"));
                    string searchUrl = "http://code.kx.com/mediawiki/index.php?title=Special:KwikiSearch&search=" + contentUrl + "&go=Go&printable=yes";
                    wbHelp.Navigate(searchUrl);
                }
            }

            //txtUrl.Text = e.Uri.OriginalString;
        }

        private void BrowseBack_CanExecute(object sender, CanExecuteRoutedEventArgs e)
        {
            e.CanExecute = ((wbHelp != null) && (wbHelp.CanGoBack));
        }

        private void BrowseBack_Executed(object sender, ExecutedRoutedEventArgs e)
        {
            wbHelp.GoBack();
        }

        private void BrowseForward_CanExecute(object sender, CanExecuteRoutedEventArgs e)
        {
            e.CanExecute = ((wbHelp != null) && (wbHelp.CanGoForward));
        }

        private void BrowseForward_Executed(object sender, ExecutedRoutedEventArgs e)
        {
            wbHelp.GoForward();
        }

        private void GoToPage_CanExecute(object sender, CanExecuteRoutedEventArgs e)
        {
            e.CanExecute = true;
        }

        private void GoToPage_Executed(object sender, ExecutedRoutedEventArgs e)
        {
            string searchUrl = "http://code.kx.com/mediawiki/index.php?title=Special:KwikiSearch&search="+ txtUrl.Text + "&go=Go&printable=yes";
            wbHelp.Navigate(searchUrl);
        }

        private void BrowseHome_CanExecute(object sender, CanExecuteRoutedEventArgs e)
        {
            e.CanExecute = true;
        }

        private void BrowseHome_Executed(object sender, ExecutedRoutedEventArgs e)
        {
            wbHelp.Navigate("http://code.kx.com/mediawiki/index.php?title=Reference&printable=yes");
        }

        void SuppressScriptErrors(System.Windows.Controls.WebBrowser wb, bool Hide)
        {

            FieldInfo fi = typeof(WebBrowser).GetField("_axIWebBrowser2", BindingFlags.Instance | BindingFlags.NonPublic);
            if (fi != null)
            {
                object browser = fi.GetValue(wb);
                if (browser != null)
                {
                    browser.GetType().InvokeMember("Silent", BindingFlags.SetProperty, null, browser, new object[] { Hide });
                }
            }
        }
    }
}
