import flask
from flask import Flask, render_template, request
from flask_socketio import SocketIO, emit
from dash import Dash
import dash_html_components as html
import dash_core_components as dcc
from dash.dependencies import Input, Output, State
from Constant import indexStr
import dashapp
from dashapp import dash_app
from dashapp import dash_cache
import pandas as pd 
import asyncio
import time
import websockets
import json


app = Flask(__name__)
app.config['SECRET_KEY'] = 'secret!'
#socketio = SocketIO(app, async_mode='threading', cors_allowed_origins="*")
socketio = SocketIO(app, async_mode='eventlet', cors_allowed_origins="*")
#cache = dict.fromkeys(['query_response','publish_response'])
cache = dash_cache.Cache()
wsUrl = "ws://localhost:8001"

# page route
@app.route('/')
def home():
    return render_template('home.html')

from dashapp.dashapp2.layout import layout as layout1
from dashapp.dashapp2.callbacks import register_callbacks as register_callbacks1
dash_app.register_dashapps(app, 'page1', layout1, register_callbacks1, socketio, cache)

from dashapp.dashapp3.layout import layout as layout2
from dashapp.dashapp3.callbacks import register_callbacks as register_callbacks2
dash_app.register_dashapps(app, 'page2', layout2, register_callbacks2, socketio, cache)

#@app.route('/dashboard')
#def render_dashboard():
#    return flask.redirect('/dashboard/')

@app.route('/about')
def about():
    return render_template('about.html')

@app.route('/db')
def db():
    return render_template('mydash.html')

@app.route('/edit', methods=['GET','POST'])
def edit():
    global socketio, cache

    if request.method == 'GET':
        layout_file = open("test/layout2.py", "r")
        layout_code = layout_file.read()
        print(layout_code)
        callback_file = open("test/callback2.py", "r")
        callback_code = callback_file.read()
        print(callback_code)
    if request.method == 'POST':
        reportId = request.form.get('reportId')
        layout_code = request.form.get('layout_code')
        print(layout_code)
        test_layout=dash_app.create_layout(layout_code)
        callback_code = request.form.get('callback_code')
        print(callback_code)
        #dash_app.register_dashapps(app, 'dashboard2', layout, register_callbacks, socketio, cache)
        dash_app.register_dashapps(app, reportId, test_layout, callback_code, socketio, cache)
    return render_template('edit.html', layout_code=layout_code, callback_code=callback_code)

async def queryWebsocket(query_msg):
    async with websockets.connect(wsUrl, close_timeout=100, max_size=None) as websocket:
        await websocket.send(query_msg)
        print(f"> {query_msg}")
        rs = await websocket.recv()
        print(f"< {rs}")
        return rs

def divide_chunks(l, n): 
    # looping till length l 
    for i in range(0, len(l), n):  
        yield l[i:i + n] 

# socketio event
@socketio.on('gui_request')
def on_gui_request(message):
    print(message)
    print(message['data'])
    print(message['type'])
    rs=asyncio.get_event_loop().run_until_complete(queryWebsocket(message['data']))
    print(rs)
    data = json.loads(rs)
    #df = pd.DataFrame(data)
    #emit('query_response', df.to_html())
    data_list = list(divide_chunks(data, 1000))
    for chunk in data_list: 
        print(chunk) 
        emit('query_response', chunk)

@socketio.on('publish_response')
def on_publish_response(message):
    #cache['publish_response']=message
    emit('broadcast_response', message, broadcast=True)

@socketio.on('connect')
def on_connect():
    emit('client_id', request.sid)
    print('Client connected')

@socketio.on('disconnect')
def on_disconnect():
    if request.sid in cache.userCache.keys():
        cache.delUserCache(request.sid)
    print('Client disconnected')

if __name__ == '__main__':
    socketio.run(app, debug=False)