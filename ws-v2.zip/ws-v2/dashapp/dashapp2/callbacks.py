import dash_html_components as html
from dash.dependencies import Input, Output, State
from flask_socketio import SocketIO, emit
import asyncio
import websockets
import json
import pandas as pd
import math
from dashapp.dash_table import gen_table
from dashapp.websocket_util import queryWebsocket

#wsUrl = "ws://localhost:8001"
#df = pd.DataFrame()

def register_callbacks(dashapp, socketio=None, cache=None):

    @dashapp.callback(
        [Output('table-sorting-filtering', 'page_current'),
        Output('result', 'style')],
        [Input('dash-button', 'n_clicks'),
        Input('feed-receiver', 'response')],
        [State('input', 'code'),
        State('url-input', 'value')])
    def query_data(n_clicks, response, code, wsUrl):
        #global df
        if response and n_clicks > 0:
            df=asyncio.get_event_loop().run_until_complete(queryWebsocket(wsUrl, code))
            #cache[eval(response)] = df
            cache.userCache[eval(response)] = df
            print(len(df))
            return 0, {'display': 'block'}
        return 0, {'display': 'none'}

    @dashapp.callback(Output('save-output', 'children'),
        [Input('save-button', 'n_clicks')],
        [State('feed-receiver', 'response'),
        State('sys-cache-input', 'value')])
    def save_data(n_clicks, response, sysCacheName):
        if response and n_clicks > 0:
            cache.systemCache[sysCacheName] = cache.userCache[eval(response)]
            return str(len(cache.systemCache[sysCacheName]))
        else:
            return ""


    @dashapp.callback(
        [Output('table-sorting-filtering', 'columns'),
        Output('table-sorting-filtering', 'data'),
        Output('table-sorting-filtering', 'page_count'),
        Output('result-output', 'children')],
        [Input('table-sorting-filtering', "page_current"),
        Input('table-sorting-filtering', "page_size"),
        Input('table-sorting-filtering', 'sort_by'),
        Input('table-sorting-filtering', 'filter_query')],
        [State('feed-receiver', 'response')])
    def update_table(page_current, page_size, sort_by, filter, response):
        #global df
        if response and eval(response) in cache.userCache.keys():
            #df = cache[eval(response)]
            df = cache.userCache[eval(response)]
        else:
            return [], [{}], 0, ""

        if len(df) > 0:
            return gen_table(df, page_current, page_size, sort_by, filter)
        else:
            return [], [{}], 0, ""