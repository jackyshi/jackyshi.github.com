from enum import Enum

class Category(Enum):
    System = 'System'
    Analytics = 'Analytics'
    BackTest = 'BackTest'

class Page:

    def addPage(self, category, pageName, pageUrl):
        if category == Category.System:
            self.pageMap.setdefault(Category.System,{})[pageName]=1
            self.pageCurrent[pageName]=pageUrl
        if category == Category.Analytics:
            self.pageMap.setdefault(Category.Analytics,{})[pageName]=1
            self.pageHistory.setdefault(pageName,{})[pageUrl]=1
            self.pageCurrent[pageName]=pageUrl
        else:
            pass

    def delPage(self, category, pageName):
        if category == Category.System:
            self.pageMap[Category.System].remove(pageName)
        if category == Category.Analytics:
            self.pageMap[Category.Analytics].remove(pageName)
        else:
            pass

    def __init__(self):
        self.pageMap = {}
        self.pageCurrent = {}
        self.pageHistory = {}