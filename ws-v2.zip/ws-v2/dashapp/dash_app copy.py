import flask
from flask import Flask, g, redirect
from dash import Dash
import dash_html_components as html 
import dash_core_components as dcc 
from flask.helpers import get_root_path
from Constant import indexStr, indexStr2, indexStr3
from dash.dependencies import Input, Output, State, ClientsideFunction
from flask_socketio import SocketIO, emit
from werkzeug.routing import Map, Rule, RuleTemplate, Submount, EndpointPrefix
import pandas as pd;	
import plotly.graph_objs as go;

g_socketio=None
g_cache=None
g_seq=1

def setSocketIO(socketio):
    global g_socketio
    g_socketio = socketio

def getSocketIO():
    global g_socketio
    return g_socketio

def setCache(cache):
    global g_cache
    g_cache = cache

def getCache():
    global g_cache
    return g_cache


def register_dashapps(app, id, layout, callbacks=None, socketio=None, cache=None):
    global g_seq

    #url = id + str(g_seq)
    url = '/'+id+'/'

    #def render_dashboard():
    #    return redirect('/'+url+'/')

    setSocketIO(socketio)
    setCache(cache)

    meta_viewport = {"name":"viewport", "content":"width=device-width, initial-scale=1, shrink-to-fit=yes"}

    newapp =  Dash (id, 
                    server=app, 
                    #assets_url_path='../assets',
                    url_base_pathname=url,
                    meta_tags=[meta_viewport])

    g_seq += 1

    with app.app_context():
        newapp.index_string=indexStr3
        newapp.title = id
        newapp.layout = layout
        if callbacks is None:
            pass
        elif callable(callbacks):
            callbacks(newapp, socketio, cache)
        elif isinstance(callbacks, str):
            levn = {'app':newapp}
            exec(callbacks, globals(), levn)
        else:
            pass
        
        #@app.route('/'+id)
        def render_dashboard():
            return redirect(url)
        #app.add_url_rule('/'+id+'/',render_dashboard())
        #app.add_url_rule('/'+id+'/',None)
        app.add_url_rule('/',endpoint=id,view_func=render_dashboard)



def create_layout(layout_code):
    levn = {}
    exec(layout_code, globals(), levn)
    return levn['layout']