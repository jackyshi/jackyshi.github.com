class Cache:

    def addUserCache(self, key, value):
        self.userCache[key] = value

    def delUserCache(self, key):
        del self.userCache[key]

    def addSystemCache(self, key, value):
        self.systemCache[key] = value

    def delSystemCache(self, key):
        del self.systemCache[key]

    def __init__(self):
        self.userCache = {}
        self.systemCache = {}