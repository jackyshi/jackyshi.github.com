@app.callback(Output('live-update-text', 'children'),
            [Input('interval-component', 'n_intervals')])
def update_data(n):
    cache = getCache()
    return [
        html.Span(cache['eventMsg']),
        html.Span(cache['broadCastMsg'])
    ]

@app.callback(
    Output('live-update-text-2','children'),
    [Input('dash-button', 'n_clicks')],
    [State('dash-input', 'value')])
def update_publish_data(n_clicks,value):
    res=[]
    if n_clicks > 0:
        socketio = getSocketIO()
        print('callback', socketio)
        socketio.emit('my response', {'data':value}, broadcast=True)
        res = [html.Span(value)]
    return res