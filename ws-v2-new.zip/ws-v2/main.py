import flask
from flask import Flask, render_template, request
from flask_socketio import SocketIO, emit
from dash import Dash
import dash_html_components as html
import dash_core_components as dcc
from dash.dependencies import Input, Output, State
from Constant import indexStr
import dashapp
from dashapp import dash_app
from dashapp import dash_cache
from dashapp import dash_pages
import pandas as pd 
import asyncio
import time
import websockets
import json


app = Flask(__name__)
app.config['SECRET_KEY'] = 'secret!'

#socketio = SocketIO(app, async_mode='threading', cors_allowed_origins="*")
socketio = SocketIO(app, async_mode='eventlet', cors_allowed_origins="*")

cache = dash_cache.Cache()
page = dash_pages.Page()

wsUrl = "ws://localhost:8001"



from dashapp.dashapp2.layout import layout as layout1
from dashapp.dashapp2.callbacks import register_callbacks as register_callbacks1
dash_app.register_dashapps(app, layout1, 'Query Data', page, dash_pages.Category.System, register_callbacks1, socketio, cache)

from dashapp.dashapp3.layout import layout as layout2
from dashapp.dashapp3.callbacks import register_callbacks as register_callbacks2
dash_app.register_dashapps(app, layout2, 'View Data', page, dash_pages.Category.System, register_callbacks2, socketio, cache)

from dashapp.dashapp4.layout import layout as layout3
from dashapp.dashapp4.callbacks import register_callbacks as register_callbacks3
dash_app.register_dashapps(app, layout3, 'Upload Data', page, dash_pages.Category.System, register_callbacks3, socketio, cache)

#@app.route('/dashboard')
#def render_dashboard():
#    return flask.redirect('/dashboard/')

# page route
@app.route('/')
def home():
    systemPages = page.pageMap[dash_pages.Category.System].keys()
    return render_template('home.html', systemPages=systemPages, pageCurrent=page.pageCurrent)

@app.route('/about')
def about():
    systemPages = page.pageMap[dash_pages.Category.System].keys()
    return render_template('about.html', systemPages=systemPages, pageCurrent=page.pageCurrent)

@app.route('/system/<pageUrl>/')
def system(pageUrl):
    systemPages = page.pageMap[dash_pages.Category.System].keys()
    return render_template('system.html', systemPages=systemPages, pageCurrent=page.pageCurrent,pageUrl=pageUrl)

@app.route('/db')
def db():
    return render_template('mydash.html')

@app.route('/edit', methods=['GET','POST'])
def edit():
    global socketio, cache
    error = ''
    pageUrl = ''
        
    if request.method == 'GET':
        layout_file = open("test/layout2.py", "r")
        layout_code = layout_file.read()
        print(layout_code)
        callback_file = open("test/callback2.py", "r")
        callback_code = callback_file.read()
        print(callback_code)
    if request.method == 'POST':
        reportId = request.form.get('reportId')
        layout_code = request.form.get('layout_code')
        print(layout_code)
        #test_layout=dash_app.create_layout(layout_code)
        callback_code = request.form.get('callback_code')
        print(callback_code)
        #dash_app.register_dashapps(app, 'dashboard2', layout, register_callbacks, socketio, cache)
        try:
            #dash_app.register_dashapps(app, test_layout, reportId, page, dash_pages.Category.Analytics, callback_code, socketio, cache)
            pageUrl = dash_app.register_dashapps(app, layout_code, reportId, page, dash_pages.Category.Analytics, callback_code, socketio, cache)
        except Exception as e:
            error = str(e)

    return render_template('edit.html', layout_code=layout_code, callback_code=callback_code, error=error, pageUrl=pageUrl)


@socketio.on('publish_response')
def on_publish_response(message):
    #cache['publish_response']=message
    emit('broadcast_response', message, broadcast=True)

@socketio.on('connect')
def on_connect():
    emit('client_id', request.sid)
    print('Client connected')

@socketio.on('disconnect')
def on_disconnect():
    if request.sid in cache.userCache.keys():
        cache.delUserCache(request.sid)
    print('Client disconnected')

if __name__ == '__main__':
    socketio.run(app, debug=False)