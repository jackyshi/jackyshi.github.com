import dash_html_components as html
import dash_core_components as dcc

layout = html.Div([
    html.H1('Dash App'),
    html.Div(id='live-update-text'),
    html.Div(id='live-update-text-2'),
    dcc.Input(id='dash-input', value=''),
    html.Button('Publish', id='dash-button', n_clicks=0),
    dcc.Interval(
        id='interval-component',
        interval=1*500,
        n_intervals=0
    )
])