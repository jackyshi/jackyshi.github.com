import asyncio
import websockets
import pandas as pd
import json

async def queryWebsocket(wsUrl, query_msg):
    try:
        async with websockets.connect(wsUrl, close_timeout=100, max_size=None) as websocket:
            await websocket.send(query_msg)
            print(f"> {query_msg}")
            rs = await websocket.recv()
            print(f"< {len(rs)}")
            res = json.loads(rs)
            if not isinstance(res, list):
                res = [{"error":res}]
    except Exception as e:
        res = [{"error":str(e)}]
    df = pd.DataFrame.from_dict(res)
    return df