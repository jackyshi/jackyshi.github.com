import dash_html_components as html
from dash.dependencies import Input, Output, State
from flask_socketio import SocketIO, emit
import asyncio
import websockets
import json
import pandas as pd
import math
from dashapp.dash_table import gen_table

def register_callbacks(dashapp, socketio=None, cache=None):

    @dashapp.callback(Output('cache-list', 'options'),
        [Input('feed-receiver', 'response'),
        Input('refresh-button', 'n_clicks')])
    def load_cachelist(response, n_clicks):
        options=[]
        if (n_clicks > 0 or response) and len(cache.systemCache.keys()) > 0:
                for i in cache.systemCache.keys():
                    options.append({'label': i, 'value': i})
        return options

    @dashapp.callback([Output('table-sorting-filtering', 'page_current'),
        Output('result', 'style')],
        [Input('cache-list', 'value')],
        [State('feed-receiver', 'response')])
    def load_cachedata(key, response):
        if response and key in cache.systemCache.keys():
            cache.userCache[eval(response)] = cache.systemCache[key]
            return 0, {'display': 'block'}
        return 0, {'display': 'none'}
 
    @dashapp.callback(
        [Output('table-sorting-filtering', 'columns'),
        Output('table-sorting-filtering', 'data'),
        Output('table-sorting-filtering', 'page_count'),
        Output('result-output', 'children')],
        [Input('table-sorting-filtering', "page_current"),
        Input('table-sorting-filtering', "page_size"),
        Input('table-sorting-filtering', 'sort_by'),
        Input('table-sorting-filtering', 'filter_query')],
        [State('feed-receiver', 'response')])
    def update_table(page_current, page_size, sort_by, filter, response):
        #global df
        if response and eval(response) in cache.userCache.keys():
            df = cache.userCache[eval(response)]
        else:
            return [], [{}], 0, ""

        if len(df) > 0:
            return gen_table(df, page_current, page_size, sort_by, filter)
        else:
            return [], [{}], 0, ""