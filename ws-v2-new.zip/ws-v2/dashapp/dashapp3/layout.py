import dash_html_components as html
import dash_core_components as dcc
import codeeditor.Codeeditor
import dash_table
import clientfeed

PAGE_SIZE = 20

layout = html.Div([

    html.Div([clientfeed.Receiver(
        id='feed-receiver',
        label='Feed Receiver',
        endpoint='http://localhost:5000',
        subject='client_id'
    )],style={'display':'none'}),

    html.Div([
        html.Button('Refresh', id='refresh-button', n_clicks=0, className="btn btn-secondary"),
        html.Div([
            dcc.Dropdown(id="cache-list",
                options=[]
            )], style={'width': '40%', 'float': 'left', 'display': 'inline-block'})
        ]),

    html.Hr(),

    dcc.Loading(id="loading-1", children=[
        html.Div(id='result-output'),
        html.Div([
            dash_table.DataTable(
            id='table-sorting-filtering',
            page_current= 0,
            page_size= PAGE_SIZE,
            page_action='custom',

            filter_action='custom',
            filter_query='',

            sort_action='custom',
            sort_mode='multi',
            sort_by=[]
            )],id='result', style={'display':'none'}
        )], type="default")
])