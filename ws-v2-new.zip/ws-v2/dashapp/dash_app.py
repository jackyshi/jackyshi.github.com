import flask
from flask import Flask, g, redirect
from dash import Dash
import dash_html_components as html 
import dash_core_components as dcc 
from flask.helpers import get_root_path
from Constant import indexStr, indexStr2, indexStr3
from dash.dependencies import Input, Output, State, ClientsideFunction
from flask_socketio import SocketIO, emit
from werkzeug.routing import Map, Rule, RuleTemplate, Submount, EndpointPrefix
from dashapp.dash_pages import Category
import pandas as pd;	
import plotly.graph_objs as go;

g_socketio=None
g_cache=None
g_pageVer={}

def setSocketIO(socketio):
    global g_socketio
    g_socketio = socketio

def getSocketIO():
    global g_socketio
    return g_socketio

def setCache(cache):
    global g_cache
    g_cache = cache

def getCache():
    global g_cache
    return g_cache


def register_dashapps(app, layout, id, page, category, callbacks=None, socketio=None, cache=None):
    global g_pageVer

    if id in g_pageVer.keys():
        ver = g_pageVer[id] + 1
    else:
        g_pageVer[id] = 0
        ver = g_pageVer[id]

    if category == Category.Analytics:
        url = '/'+id + '-' + str(ver) +'/'
    else:
        url = '/'+id+'/'

    setSocketIO(socketio)
    setCache(cache)

    meta_viewport = {"name":"viewport", "content":"width=device-width, initial-scale=1, shrink-to-fit=yes"}

    newapp =  Dash (id, 
                    server=app, 
                    #assets_url_path='../assets',
                    url_base_pathname=url,
                    meta_tags=[meta_viewport])

    with app.app_context():
        newapp.index_string=indexStr3
        newapp.title = id

        levn = {'app':newapp}
        #layout
        if isinstance(layout, str):
            exec(layout, globals(), levn)
        else:
            newapp.layout = layout
        #callback
        if callbacks is None:
            pass
        elif callable(callbacks):
            callbacks(newapp, socketio, cache)
        elif isinstance(callbacks, str):
            exec(callbacks, globals(), levn)
        else:
            pass
        
        def render_dashboard():
            return redirect(url)

        app.add_url_rule(url,render_dashboard())
        #app.add_url_rule('/',endpoint=id,view_func=render_dashboard)
    
    page.addPage(category, id, url)
    return url



def create_layout(layout_code):
    levn = {}
    exec(layout_code, globals(), levn)
    return levn['layout']