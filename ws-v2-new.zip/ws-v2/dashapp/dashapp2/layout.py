import dash_html_components as html
import dash_core_components as dcc
import codeeditor.Codeeditor
import dash_table
import clientfeed

PAGE_SIZE = 10

layout = html.Div([
    codeeditor.Codeeditor(
        id='input',
        code='',
        label='Query Editor',
        mode='q',
        theme='midnight',
        tabSize=2,
        indentUnit=2
    ),

    html.Br(),

    html.Div([
        html.Div([
            html.Div([
                html.Div([html.Div(["KDB URL"],className="input-group-text")],className="input-group-prepend"),
                dcc.Input(id='url-input', value='ws://localhost:8001', className="form-control"),
                html.Button('Query', id='dash-button', n_clicks=0, className="btn btn-secondary btn-sm")
            ],className="input-group mb-2")
        ],className="col-auto"),
        html.Div([
            html.Div([
                html.Div([html.Div(["System Cache key"],className="input-group-text")],className="input-group-prepend"),
                dcc.Input(id='sys-cache-input', value='', className="form-control"),
                html.Button('Save', id='save-button', n_clicks=0, className="btn btn-secondary btn-sm"),
                html.Div(id='save-output')
            ],className="input-group mb-2")
        ],className="col-auto")
    ], className="form-inline"),

    html.Div([clientfeed.Receiver(
        id='feed-receiver',
        label='Feed Receiver',
        endpoint='http://localhost:5000',
        subject='client_id'
    )],style={'display':'none'}),

    html.Hr(),

    dcc.Loading(id="loading-1", children=[
        html.Div(id='result-output'),
        html.Div([
            dash_table.DataTable(
            id='table-sorting-filtering',
            page_current= 0,
            page_size= PAGE_SIZE,
            page_action='custom',

            filter_action='custom',
            filter_query='',

            sort_action='custom',
            sort_mode='multi',
            sort_by=[]
            )],id='result', style={'display':'none'}
        )], type="default")
])